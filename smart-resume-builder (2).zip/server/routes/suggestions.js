const express = require("express");
const router = express.Router();
const axios = require("axios");

router.post("/", async (req, res) => {
  const prompt = `Improve this resume content:\n${JSON.stringify(req.body, null, 2)}`;

  try {
    const response = await axios.post(
      "https://api.openai.com/v1/completions",
      {
        model: "text-davinci-003",
        prompt,
        max_tokens: 300,
        temperature: 0.7,
      },
      {
        headers: {
          Authorization: `Bearer ${process.env.OPENAI_API_KEY}`,
        },
      }
    );

    res.send(response.data.choices[0].text.trim());
  } catch (err) {
    res.status(500).send("Error from OpenAI");
  }
});

module.exports = router;
