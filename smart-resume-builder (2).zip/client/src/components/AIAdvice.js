import React, { useContext, useState } from "react";
import axios from "axios";
import { ResumeContext } from "../context/ResumeContext";

function AIAdvice() {
  const { resume } = useContext(ResumeContext);
  const [suggestion, setSuggestion] = useState("");

  const getSuggestion = async () => {
    const res = await axios.post("http://localhost:5000/api/suggestions", resume);
    setSuggestion(res.data);
  };

  return (
    <div className="mt-4">
      <button onClick={getSuggestion} className="btn">Get AI Suggestions</button>
      {suggestion && <p className="mt-2 text-sm text-green-700 whitespace-pre-line">{suggestion}</p>}
    </div>
  );
}

export default AIAdvice;
