import React, { useContext } from "react";
import { ResumeContext } from "../context/ResumeContext";

function ResumeForm() {
  const { resume, setResume } = useContext(ResumeContext);

  const updateField = (e) => {
    setResume({ ...resume, [e.target.name]: e.target.value });
  };

  return (
    <form className="bg-white p-4 rounded shadow">
      <h2 className="text-xl font-semibold mb-2">Fill Resume Details</h2>
      <input name="name" placeholder="Full Name" onChange={updateField} className="input" />
      <input name="email" placeholder="Email" onChange={updateField} className="input" />
      <textarea name="summary" placeholder="Professional Summary" onChange={updateField} className="input"></textarea>
    </form>
  );
}

export default ResumeForm;
