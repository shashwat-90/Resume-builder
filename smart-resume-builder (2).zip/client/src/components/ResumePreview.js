import React, { useContext, forwardRef } from "react";
import { ResumeContext } from "../context/ResumeContext";

const ResumePreview = forwardRef((props, ref) => {
  const { resume } = useContext(ResumeContext);

  return (
    <div ref={ref} className="bg-white p-4 rounded shadow print:shadow-none">
      <h2 className="text-2xl font-bold">{resume.name}</h2>
      <p className="text-sm text-gray-600">{resume.email}</p>
      <p>{resume.summary}</p>
    </div>
  );
});

export default ResumePreview;
