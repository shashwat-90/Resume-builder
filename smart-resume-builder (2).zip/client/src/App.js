import React from "react";
import ResumeForm from "./components/ResumeForm";
import ResumePreview from "./components/ResumePreview";
import AIAdvice from "./components/AIAdvice";
import ReactToPrint from "react-to-print";

function App() {
  const previewRef = React.useRef();

  return (
    <div className="p-4 bg-gray-50 min-h-screen">
      <h1 className="text-3xl font-bold text-center mb-6">Smart Resume Builder</h1>
      <div className="grid md:grid-cols-2 gap-6">
        <ResumeForm />
        <div>
          <ResumePreview ref={previewRef} />
          <ReactToPrint
            trigger={() => <button className="btn mt-4">Download PDF</button>}
            content={() => previewRef.current}
          />
          <AIAdvice />
        </div>
      </div>
    </div>
  );
}

export default App;
