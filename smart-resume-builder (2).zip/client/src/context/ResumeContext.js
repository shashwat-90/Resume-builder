import React, { createContext, useState } from "react";
export const ResumeContext = createContext();

export function ResumeProvider({ children }) {
  const [resume, setResume] = useState({});
  return (
    <ResumeContext.Provider value={{ resume, setResume }}>
      {children}
    </ResumeContext.Provider>
  );
}
